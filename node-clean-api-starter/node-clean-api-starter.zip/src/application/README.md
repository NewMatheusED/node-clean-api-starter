# Application

Contém os casos de uso da aplicação.
Orquestra o fluxo entre domínio e infraestrutura.
Não depende de frameworks web.
