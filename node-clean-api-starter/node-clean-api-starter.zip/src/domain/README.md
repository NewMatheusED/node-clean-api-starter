# Domain

Contém as regras de negócio puras da aplicação.
Sem dependência de frameworks.
