# Infrastructure

Contém implementações técnicas.
Acesso a banco de dados, mensageria, cache e serviços externos.
Depende de frameworks e bibliotecas.
