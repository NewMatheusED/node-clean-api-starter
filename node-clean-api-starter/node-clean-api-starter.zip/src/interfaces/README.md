# Interfaces

Define contratos de entrada e saída.
Controllers, presenters e DTOs.
Camada de adaptação entre mundo externo e aplicação.
