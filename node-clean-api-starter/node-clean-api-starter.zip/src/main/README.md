# Main

Camada de composição da aplicação.
Configuração de frameworks, rotas e injeção de dependências.
Ponto de entrada do sistema.
