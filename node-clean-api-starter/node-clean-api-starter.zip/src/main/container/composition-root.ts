import { InMemoryUserRepository } from '../../infrastructure/repositories/InMemoryUserRepository'

export const userRepository = new InMemoryUserRepository()
